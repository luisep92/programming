﻿using DAM;

namespace El_raton_y_el_gato
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Game.Launch(new TomAndJerry());
        }
    }
}