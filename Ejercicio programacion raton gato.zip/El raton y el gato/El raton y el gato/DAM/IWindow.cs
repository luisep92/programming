﻿using System;

namespace DAM
{
    public interface IWindow
    {
        void Close();
    }
}

