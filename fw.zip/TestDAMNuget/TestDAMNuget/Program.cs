﻿namespace TestDAMNuget;

class Program
{
    static void Main(string[] args)
    {
        //DAM.Game.Launch(new Sample_Nothing());
        //DAM.Game.Launch(new Sample_FillRect());
        //DAM.Game.Launch(new Sample_FillImage());
        DAM.Game.Launch(new Sample_Gradient());
        //DAM.Game.Launch(new Sample_OnePixelLine());
        //DAM.Game.Launch(new Sample_FillText());
        //DAM.Game.Launch(new Sample_PlaySound());
        //DAM.Game.Launch(new Sample_PlayMusic());
        //DAM.Game.Launch(new Sample_SimpleMask());
        //DAM.Game.Launch(new Sample_Animation());
    }
}

